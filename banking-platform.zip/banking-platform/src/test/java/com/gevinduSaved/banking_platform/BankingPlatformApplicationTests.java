package com.gevinduSaved.banking_platform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingPlatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
